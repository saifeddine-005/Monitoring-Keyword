<?php
// config/ziggy.php

return [
    'whitelist' => [
        'dashboard',
        'domains.*',  // Tüm domains rotalarını dahil eder
        'keywords.*',
        'keyword-positions.*',
    ],
];